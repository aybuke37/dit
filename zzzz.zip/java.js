/*jslint browser: true, devel: true, eqeq: true, plusplus: true, sloppy: true, vars: true, white: true*/
/*eslint-env browser*/
/*eslint 'no-console':0*/

var buttonSorteren = document.querySelector('#sorteren');
var buttonFilteren = document.querySelector('#filteren');
var formSorteren = document.querySelector('#formSorteren');
var formFilteren = document.querySelector('#formFilteren');

function openSorteren() {
    console.log("bla");
    formSorteren.classList.remove('hidden');
    formFilteren.classList.add('hidden');
}

buttonSorteren.addEventListener('click', openSorteren);

function openFilteren() {
    formSorteren.classList.add('hidden');
    formFilteren.classList.remove('hidden');
}


buttonFilteren.addEventListener('click', openFilteren);
